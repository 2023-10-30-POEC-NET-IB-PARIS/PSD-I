describe('Form testing', () => {
    // test e2e (fonctionnel)
    beforeEach(() => {
        cy.visit('/') // visiter la page à tester
    })
    // scenario format correct
    it('Should have correct email', () => {
        // on rentre une adresse e-mail correct
        cy.get('input[type=email]').type('contact@tshimini.fr')
        // donc on s'attend à ne pas avoir d'erreur
        cy.get('alert.alert-error').should('not.exist')
    })

    // scenario mauvais format d'email
    it('Should have wrong email', () => {
        // On rentre un mauvais format pour l'adresse e-mail
        cy.get('input[type=email]').type('contact@tshimini')
        // Donc s'attend à avoir le message d'erreur
        cy.get('.alert.alert-error').should('have.text', 'Email incorrecte')
    })

    // Scenario au départ mauvais format puis bon format
    it('Should remove Error', () => {
        // on renseigne le'email au mauvais format
        cy.get('input[type=email]').type('contact@tshimini')
        // On ajoute l'extension donc on a un format correct
        cy.wait(5000)
        cy.get('input[type=email]').type('.fr')
        // Donc s'attend que le message disparait
        cy.get('.alert.alert-error').should($el => {
            expect($el[0].innerHTML).to.equals('')
        })
    })
    
    it.skip('Should have a title', () => {
        cy.get('h1').should('exist')
    })

})