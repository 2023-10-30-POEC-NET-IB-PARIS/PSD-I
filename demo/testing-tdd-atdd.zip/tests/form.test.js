import {describe, it, expect} from 'vitest'
import Form from '../src/form'
import userEvent from '@testing-library/user-event'
const form = new Form()
describe('form testing', () => {
    describe('Check Email', () => {
        it('Should have correct email format', () => {
            expect(form.checkEmail('contact@tshimini.fr')).toBe(true)
        })
        
        it('Should have wrong email format', () => {
            expect(form.checkEmail('contact@tshimini')).toBe(false)
        })
        
        it('Should have correct email format with paris extension', () => {
            expect(form.checkEmail('contact@tshimini.paris')).toBe(true)
        })
    })

    describe('Show and remove Error', () => {
        it('Should show error message', async () => {
            // Arrange
            document.body.innerHTML = `
            <p class="alert alert-error"></p>
            <input type="email" placeholder="Email" />
            `
            // Act
            form.showError()
            await userEvent.type(document.querySelector('[type=email]'), 'contact@tshimini')
            // Assert
            const err = document.querySelector('.alert.alert-error').innerHTML
            expect(err).toEqual('Email incorrecte')
        })

        it('Should remove error message', async () => {
            // Arrange
            document.body.innerHTML = `
            <p class="alert alert-error">Email incorrecte</p>
            <input type="email" placeholder="Email" />
            `
            // Act
            form.showError()
            await userEvent.type(document.querySelector('[type=email]'), 'contact@tshimini.fr')
            // Assert
            const err = document.querySelector('.alert.alert-error').innerHTML
            expect(err).toEqual('')
        })
    })
})