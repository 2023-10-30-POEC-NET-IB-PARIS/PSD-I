export default class Form {
    checkEmail(email) {
        return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,5})+$/.test(email)
    }

    showError() {
        document.querySelector('[type=email]').addEventListener('keyup', (e) => {
            const msg = !this.checkEmail(e.target.value) ? 'Email incorrecte' : ''
            document.querySelector('.alert.alert-error').innerHTML = msg
        })
    }
}