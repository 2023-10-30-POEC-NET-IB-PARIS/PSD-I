import Form from './form.js'

const form = new Form()
form.showError()