# Outils pour les tests

---

## Environnement

- Node Js

---

## Package

- package vitest pour les tests unitaires
- package cypress pour les tests E2E

## Installation

- `npm install` depuis un terminal et la racine du projet

## Testing

### Lancer les tests fonctionnels

1. Utilisez l'extension Live Server de VSCODE pour lancer l'application (index.html)
2. Tapez la commande `npm run e2e` depuis un terminal et la racine du projet 


### Lancer les tests unitaires

1. Tapez la commande `npm run test` depuis un terminal et la racine du projet